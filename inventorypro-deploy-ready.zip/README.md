# InventoryPro.in

Restaurant inventory & food-cost control. React (frontend) + FastAPI (backend) + MongoDB Atlas.
Deployment steps: see [DEPLOY.md](DEPLOY.md). Auth API notes: [auth_testing.md](auth_testing.md).
