import { useEffect, useState } from "react";
import { toast } from "sonner";
import api, { fmtErr } from "../api";
import { useAuth } from "../AuthContext";
import { Card, DataTable, DEPARTMENTS, Field, PageHead, fmtNum, inputCls } from "../components";

export default function Issue() {
  const { user } = useAuth();
  const [ings, setIngs] = useState([]);
  const [history, setHistory] = useState([]);
  const [form, setForm] = useState({ ingredient_id: "", qty: "", dept: DEPARTMENTS[0], requested_by: "" });
  const [saving, setSaving] = useState(false);

  const load = () => {
    api.get("/ingredients").then((r) => setIngs(r.data)).catch((e) => toast.error(fmtErr(e)));
    api.get("/issues").then((r) => setHistory(r.data)).catch((e) => toast.error(fmtErr(e)));
  };
  useEffect(() => {
    setForm((f) => ({ ...f, requested_by: user.name }));
    load();
  }, []);

  const ing = ings.find((i) => i.id === form.ingredient_id);

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post("/issues", { ...form, qty: Number(form.qty) });
      toast.success(`Issued ${form.qty} ${ing?.unit} of ${ing?.name} to ${form.dept}`);
      setForm((f) => ({ ...f, qty: "" }));
      load();
    } catch (e2) { toast.error(fmtErr(e2)); } finally { setSaving(false); }
  };

  return (
    <div data-testid="issue-page">
      <PageHead title="Store Issue" sub="Move raw material from Central Store to a production department" testId="issue-head" />
      <Card className="mb-8" testId="issue-form-card">
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="Ingredient">
            <select required value={form.ingredient_id} onChange={(e) => setForm((f) => ({ ...f, ingredient_id: e.target.value }))} data-testid="issue-ingredient-select" className={`${inputCls} appearance-none`}>
              <option value="" className="bg-brand-slate">Select…</option>
              {ings.map((i) => <option key={i.id} value={i.id} className="bg-brand-slate">{i.name} — {fmtNum(i.book_stock)} {i.unit} available</option>)}
            </select>
          </Field>
          <Field label="Quantity"><input required type="number" step="any" min="0.001" value={form.qty} onChange={(e) => setForm((f) => ({ ...f, qty: e.target.value }))} data-testid="issue-qty-input" className={inputCls} placeholder="2.5" /></Field>
          <Field label="Destination Department">
            <select value={form.dept} onChange={(e) => setForm((f) => ({ ...f, dept: e.target.value }))} data-testid="issue-dept-select" className={`${inputCls} appearance-none`}>
              {DEPARTMENTS.map((d) => <option key={d} className="bg-brand-slate">{d}</option>)}
            </select>
          </Field>
          <Field label="Requested By"><input value={form.requested_by} onChange={(e) => setForm((f) => ({ ...f, requested_by: e.target.value }))} data-testid="issue-requested-input" className={inputCls} /></Field>
          <div className="flex items-end">
            <button type="submit" disabled={saving} data-testid="issue-submit-button" className="w-full rounded-xl bg-brand-terra py-2.5 text-sm font-semibold text-white disabled:opacity-60">
              {saving ? "Issuing..." : "Issue Stock"}
            </button>
          </div>
        </form>
      </Card>
      <h2 className="mb-4 font-display text-lg font-bold">Issue Transaction History</h2>
      <DataTable
        testId="issue-history-table"
        cols={["Date", "Ingredient", "Qty", "Department", "Requested By"]}
        rows={history.map((h) => [h.date, h.ingredient_name, <span className="font-mono">{fmtNum(h.qty)}</span>, h.dept, h.requested_by])}
      />
    </div>
  );
}
