import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Mail, Phone, Building2, Inbox, Check, Archive, RotateCcw } from "lucide-react";
import api, { fmtErr } from "../api";
import { Card, PageHead } from "../components";

const TABS = [["all", "All"], ["new", "New"], ["contacted", "Contacted"], ["archived", "Archived"]];
const BADGE = {
  new: "bg-brand-terra/15 text-brand-terra",
  contacted: "bg-brand-emerald/15 text-brand-emerald",
  archived: "bg-white/10 text-muted-foreground",
};

export default function Enquiries() {
  const [rows, setRows] = useState(null);
  const [filter, setFilter] = useState("all");

  const load = () => api.get("/enquiries").then((r) => setRows(r.data)).catch((e) => toast.error(fmtErr(e)));
  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    try {
      await api.put(`/enquiries/${id}/status`, { status });
      toast.success(status === "contacted" ? "Marked as contacted" : status === "archived" ? "Enquiry archived" : "Moved back to new");
      load();
    } catch (e) { toast.error(fmtErr(e)); }
  };

  const counts = (rows || []).reduce((a, q) => ({ ...a, [q.status]: (a[q.status] || 0) + 1 }), {});
  const visible = (rows || []).filter((q) => filter === "all" || q.status === filter);

  return (
    <div data-testid="enquiries-page">
      <PageHead
        title="Enquiry Inbox"
        sub="Every website demo request — saved here even if an email never reaches you"
        testId="enquiries-head"
      />
      <div className="mb-6 flex flex-wrap gap-2" data-testid="enquiries-filter-tabs">
        {TABS.map(([v, l]) => (
          <button
            key={v}
            onClick={() => setFilter(v)}
            data-testid={`enquiries-tab-${v}`}
            className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${filter === v ? "bg-brand-terra text-white" : "border border-white/10 text-muted-foreground hover:text-foreground"}`}
          >
            {l}{v !== "all" && counts[v] ? ` (${counts[v]})` : ""}
          </button>
        ))}
      </div>
      {rows === null ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : visible.length === 0 ? (
        <Card testId="enquiries-empty">
          <div className="flex flex-col items-center gap-3 py-10 text-center">
            <Inbox className="size-10 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              {rows.length === 0 ? "No enquiries yet — share your landing page and they will land here." : `No ${filter} enquiries.`}
            </p>
          </div>
        </Card>
      ) : (
        <div className="space-y-4" data-testid="enquiries-list">
          {visible.map((q) => (
            <Card key={q.id} testId={`enquiry-card-${q.id}`} className={q.status === "archived" ? "opacity-60" : ""}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-lg font-bold tracking-tight">{q.restaurant_name}</h3>
                  <p className="mt-0.5 text-sm text-muted-foreground">
                    {q.name} · {new Date(q.created_at).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`rounded-full px-3 py-1 font-mono text-[10px] uppercase tracking-widest ${BADGE[q.status] || BADGE.new}`} data-testid={`enquiry-status-${q.id}`}>
                    {q.status}
                  </span>
                  <span className="flex items-center gap-1.5 rounded-full bg-brand-gold/15 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-brand-gold">
                    <Building2 className="size-3" /> {q.outlets || "1 Outlet"}
                  </span>
                </div>
              </div>
              {q.message && (
                <p className="mt-3 rounded-xl border border-white/8 bg-black/20 px-4 py-3 text-sm text-muted-foreground">
                  “{q.message}”
                </p>
              )}
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <a href={`mailto:${q.email}`} data-testid={`enquiry-email-${q.id}`}
                  className="flex items-center gap-2 rounded-full border border-white/10 px-4 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-brand-terra/60 hover:text-foreground">
                  <Mail className="size-3.5" /> {q.email}
                </a>
                <a href={`tel:${q.phone}`} data-testid={`enquiry-phone-${q.id}`}
                  className="flex items-center gap-2 rounded-full border border-white/10 px-4 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-brand-emerald/60 hover:text-foreground">
                  <Phone className="size-3.5" /> {q.phone}
                </a>
                <span className="ml-auto flex gap-2">
                  {q.status !== "contacted" && (
                    <button onClick={() => setStatus(q.id, "contacted")} data-testid={`enquiry-contacted-${q.id}`}
                      className="flex items-center gap-1.5 rounded-full bg-brand-emerald/15 px-4 py-2 text-xs font-semibold text-brand-emerald transition-colors hover:bg-brand-emerald hover:text-white">
                      <Check className="size-3.5" /> Mark Contacted
                    </button>
                  )}
                  {q.status !== "archived" ? (
                    <button onClick={() => setStatus(q.id, "archived")} data-testid={`enquiry-archive-${q.id}`}
                      className="flex items-center gap-1.5 rounded-full border border-white/10 px-4 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground">
                      <Archive className="size-3.5" /> Archive
                    </button>
                  ) : (
                    <button onClick={() => setStatus(q.id, "new")} data-testid={`enquiry-restore-${q.id}`}
                      className="flex items-center gap-1.5 rounded-full border border-white/10 px-4 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground">
                      <RotateCcw className="size-3.5" /> Restore
                    </button>
                  )}
                </span>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

