import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Bar, BarChart, CartesianGrid, Cell, ComposedChart, Line, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import api, { fmtErr } from "../api";
import { Card, PageHead, Stat, fmtINR } from "../components";

const COLORS = ["#FF5722", "#E6A100", "#10B981", "#64748B", "#8B5CF6", "#38BDF8"];
const tooltipStyle = { background: "#131620", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 12 };

function Donut({ title, data, inr = false, testId }) {
  const total = data.reduce((a, b) => a + b.value, 0);
  return (
    <Card testId={testId}>
      <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{title}</p>
      <div className="relative mt-2 h-44">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius="60%" outerRadius="85%" paddingAngle={3} stroke="none">
              {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Pie>
            <Tooltip contentStyle={tooltipStyle} itemStyle={{ color: "#F3F4F6" }} />
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <p className="font-display text-xl font-bold">{inr ? fmtINR(total) : total}</p>
        </div>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1">
        {data.map((d, i) => (
          <span key={d.name} className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="size-2 shrink-0 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
            <span className="truncate">{d.name}</span>
            <span className="ml-auto font-mono text-[11px] text-foreground">{inr ? fmtINR(d.value) : d.value}</span>
          </span>
        ))}
      </div>
    </Card>
  );
}

export default function Dashboard() {
  const [d, setD] = useState(null);
  useEffect(() => {
    api.get("/dashboard").then((r) => setD(r.data)).catch((e) => toast.error(fmtErr(e)));
  }, []);
  if (!d) {
    return <div className="grid h-64 place-items-center text-sm text-muted-foreground" data-testid="dashboard-loading">Loading dashboard…</div>;
  }
  const fcOk = d.food_cost_pct <= d.food_cost_target;
  return (
    <div data-testid="app-dashboard">
      <PageHead title="Dashboard" sub={`Today's performance at a glance · ${d.date}`} testId="dashboard-head" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <Stat label="Today's Sales" value={fmtINR(d.sales_value)} sub={`${d.portions_sold} portions sold`} testId="stat-sales" />
        <Stat label="Food Cost %" value={`${d.food_cost_pct}%`} sub={fcOk ? `Within target (≤${d.food_cost_target}%)` : `Above target (≤${d.food_cost_target}%)`} tone={fcOk ? "text-brand-emerald" : "text-brand-gold"} testId="stat-food-cost" />
        <Stat label="Raw Material Stock" value={fmtINR(d.stock_value)} sub={`${d.ingredients_count} ingredients tracked`} testId="stat-stock" />
        <Stat label="Today's Production" value={d.produced_portions} sub={`${d.batches_count} batches logged`} testId="stat-production" />
        <Stat label="Today's Wastage" value={fmtINR(d.wastage_value)} sub={`${d.wastage_entries} entries recorded`} tone="text-brand-gold" testId="stat-wastage" />
        <Stat label="Unexplained Variance" value={`${d.unexplained_portions} portions`} sub={`${d.variance_items} stock items to review`} tone={d.unexplained_portions ? "text-brand-terra" : "text-brand-emerald"} testId="stat-variance" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" testId="seven-day-chart">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">7-Day Sales & Food Cost %</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={d.seven_day}>
                <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} unit="%" />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar yAxisId="left" dataKey="sales" name="Sales (₹)" fill="#FF5722" radius={[6, 6, 0, 0]} barSize={22} />
                <Line yAxisId="right" dataKey="food_cost" name="Food cost %" stroke="#E6A100" strokeWidth={2} dot={{ r: 3 }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card testId="stock-category-chart">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Stock Value by Category</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={d.stock_by_category} layout="vertical">
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v) => [fmtINR(v), "Value"]} />
                <Bar dataKey="value" fill="#10B981" radius={[0, 6, 6, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Donut title="Wastage Breakdown (7 days)" data={d.wastage_pie} inr testId="app-wastage-pie" />
        <Donut title="Production Today (portions)" data={d.production_pie} testId="app-production-pie" />
        <Donut title="POS Sales Today (₹)" data={d.sales_pie} inr testId="app-sales-pie" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card testId="attention-list">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Needs Attention</p>
          {d.attention.length === 0 ? (
            <p className="text-sm text-brand-emerald">Everything is accounted for today.</p>
          ) : (
            <ul className="space-y-2.5">
              {d.attention.map((a, i) => (
                <li key={i} className="flex items-start gap-3 rounded-xl border border-white/8 bg-black/20 px-4 py-3 text-sm">
                  <span className={`mt-1.5 size-2 shrink-0 rounded-full ${a.tone === "terra" ? "bg-brand-terra" : a.tone === "gold" ? "bg-brand-gold" : "bg-brand-emerald"}`} />
                  {a.text}
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card testId="reconciliation-summary">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Reconciliation Status</p>
          <ul className="space-y-2.5">
            {d.reconciliation.filter((r) => r.produced > 0 || r.sold > 0).map((r) => (
              <li key={r.dish_id} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-black/20 px-4 py-3 text-sm">
                <span>{r.dish_name} <span className="text-muted-foreground">· {r.sold}/{r.produced} sold</span></span>
                <span className={`shrink-0 rounded-full px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-widest ${r.status === "reconciled" ? "bg-brand-emerald/15 text-brand-emerald" : r.status === "over-sold" ? "bg-brand-terra/15 text-brand-terra" : "bg-brand-gold/15 text-brand-gold"}`}>
                  {r.status === "reconciled" ? "Reconciled" : r.status === "over-sold" ? `${Math.abs(r.unexplained)} over-sold` : `${r.unexplained} unexplained`}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
