import { useEffect, useState } from "react";
import { toast } from "sonner";
import api, { fmtErr } from "../api";
import { Card, DataTable, PageHead, fmtINR, fmtNum } from "../components";

export default function Variance() {
  const [v, setV] = useState(null);
  useEffect(() => {
    api.get("/variance").then((r) => setV(r.data)).catch((e) => toast.error(fmtErr(e)));
  }, []);
  if (!v) return <p className="text-sm text-muted-foreground">Loading…</p>;

  return (
    <div data-testid="variance-page">
      <PageHead title="Variance Center" sub="Expected vs actual across stock, production and sales — today" testId="variance-head" />
      <div className="space-y-8">
        <div>
          <h2 className="mb-4 font-display text-lg font-bold">Stock Variance (book vs physical)</h2>
          <DataTable
            testId="variance-stock-table"
            cols={["Ingredient", "Book Stock", "Physical", "Variance", "Value Impact"]}
            empty="No stock variance — book matches physical everywhere."
            rows={v.stock_variance.map((s) => [
              s.ingredient,
              <span className="font-mono">{fmtNum(s.book)} {s.unit}</span>,
              <span className="font-mono">{fmtNum(s.physical)} {s.unit}</span>,
              <span className={`font-mono ${s.variance < 0 ? "text-brand-terra" : "text-brand-emerald"}`}>{s.variance > 0 ? "+" : ""}{fmtNum(s.variance)} {s.unit}</span>,
              <span className="font-mono text-brand-gold">{fmtINR(Math.abs(s.value))}</span>,
            ])}
          />
        </div>
        <div>
          <h2 className="mb-4 font-display text-lg font-bold">Portion Variance (produced vs accounted)</h2>
          <DataTable
            testId="variance-dish-table"
            cols={["Dish", "Produced", "Sold", "Accounted", "Unexplained"]}
            empty="Every portion produced today is accounted for."
            rows={v.dish_variance.map((d) => [
              d.dish_name,
              <span className="font-mono">{d.produced}</span>,
              <span className="font-mono">{d.sold}</span>,
              <span className="font-mono">{d.accounted}</span>,
              <span className={`font-mono ${d.unexplained < 0 ? "text-brand-terra" : "text-brand-gold"}`}>{d.unexplained > 0 ? "+" : ""}{d.unexplained}</span>,
            ])}
          />
        </div>
        <div>
          <h2 className="mb-4 font-display text-lg font-bold">Issued — Awaiting Consumption</h2>
          <Card testId="variance-dept-list">
            <ul className="divide-y divide-white/5">
              {v.dept_residual.map((d) => (
                <li key={d.ingredient} className="flex items-center justify-between py-3 text-sm">
                  <span>{d.ingredient} <span className="text-muted-foreground">· {Object.entries(d.depts).map(([k, val]) => `${fmtNum(val)} ${d.unit} → ${k}`).join(", ")}</span></span>
                  <span className="font-mono text-muted-foreground">{fmtINR(d.value)}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
