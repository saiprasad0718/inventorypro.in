import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import api, { fmtErr } from "../api";
import { Card, DataTable, Field, PageHead, fmtINR, fmtNum, inputCls } from "../components";

export default function Inventory() {
  const [items, setItems] = useState([]);
  const [phys, setPhys] = useState({});
  const [showAdd, setShowAdd] = useState(false);
  const [add, setAdd] = useState({ name: "", category: "Vegetables", unit: "kg", rate: "", opening_stock: "" });

  const load = () =>
    api.get("/ingredients").then((r) => {
      setItems(r.data);
      setPhys(Object.fromEntries(r.data.map((i) => [i.id, i.physical_stock])));
    }).catch((e) => toast.error(fmtErr(e)));
  useEffect(() => { load(); }, []);

  const savePhys = async (id) => {
    try {
      await api.put(`/ingredients/${id}/physical`, { physical_stock: Number(phys[id]) || 0 });
      toast.success("Physical stock updated");
      load();
    } catch (e) { toast.error(fmtErr(e)); }
  };

  const addItem = async (e) => {
    e.preventDefault();
    try {
      await api.post("/ingredients", { ...add, rate: Number(add.rate), opening_stock: Number(add.opening_stock) || 0 });
      toast.success("Ingredient added");
      setShowAdd(false);
      setAdd({ name: "", category: "Vegetables", unit: "kg", rate: "", opening_stock: "" });
      load();
    } catch (e2) { toast.error(fmtErr(e2)); }
  };

  const rows = items.map((i) => {
    const v = Math.round((Number(phys[i.id]) || 0) - i.book_stock, 3) * 1;
    return [
      <span className="font-medium">{i.name}</span>,
      <span className="text-muted-foreground">{i.category}</span>,
      `${fmtINR(i.rate)}/${i.unit}`,
      <span className="font-mono">{fmtNum(i.book_stock)} {i.unit}</span>,
      <span className="font-mono text-muted-foreground">{fmtNum(i.dept_total)} {i.unit}</span>,
      <span className="flex items-center gap-2">
        <input
          type="number" step="any" min="0"
          value={phys[i.id] ?? ""}
          onChange={(e) => setPhys((p) => ({ ...p, [i.id]: e.target.value }))}
          data-testid={`physical-input-${i.id}`}
          className="w-24 rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-sm outline-none focus:border-brand-terra/60"
        />
        <button onClick={() => savePhys(i.id)} data-testid={`physical-save-${i.id}`} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-xs text-muted-foreground transition-colors hover:border-brand-emerald/60 hover:text-brand-emerald">Save</button>
      </span>,
      <span className={`font-mono ${Math.abs(v) < 0.001 ? "text-brand-emerald" : "text-brand-gold"}`}>{Math.abs(v) < 0.001 ? "OK" : `${v > 0 ? "+" : ""}${fmtNum(v)}`}</span>,
      <span className="font-mono">{fmtINR(i.stock_value)}</span>,
    ];
  });

  return (
    <div data-testid="inventory-page">
      <div className="flex items-start justify-between gap-4">
        <PageHead title="Inventory" sub="Live book stock across all raw materials — enter physical counts to surface variance" testId="inventory-head" />
        <button onClick={() => setShowAdd((s) => !s)} data-testid="add-ingredient-toggle" className="flex shrink-0 items-center gap-2 rounded-full bg-brand-terra px-4 py-2 text-sm font-semibold text-white transition-transform hover:scale-[1.03]">
          <Plus className="size-4" /> Add Ingredient
        </button>
      </div>
      {showAdd && (
        <Card className="mb-6" testId="add-ingredient-form">
          <form onSubmit={addItem} className="grid gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <Field label="Name"><input required value={add.name} onChange={(e) => setAdd((a) => ({ ...a, name: e.target.value }))} data-testid="add-ing-name" className={inputCls} placeholder="Cashew" /></Field>
            <Field label="Category">
              <select value={add.category} onChange={(e) => setAdd((a) => ({ ...a, category: e.target.value }))} data-testid="add-ing-category" className={`${inputCls} appearance-none`}>
                {["Meat", "Vegetables", "Dairy", "Dry Goods", "Oil", "Spices", "Other"].map((c) => <option key={c} className="bg-brand-slate">{c}</option>)}
              </select>
            </Field>
            <Field label="Unit">
              <select value={add.unit} onChange={(e) => setAdd((a) => ({ ...a, unit: e.target.value }))} data-testid="add-ing-unit" className={`${inputCls} appearance-none`}>
                {["kg", "g", "L", "ml", "pcs"].map((u) => <option key={u} className="bg-brand-slate">{u}</option>)}
              </select>
            </Field>
            <Field label="Rate (₹/unit)"><input required type="number" step="any" min="0.01" value={add.rate} onChange={(e) => setAdd((a) => ({ ...a, rate: e.target.value }))} data-testid="add-ing-rate" className={inputCls} placeholder="480" /></Field>
            <Field label="Opening Stock"><input type="number" step="any" min="0" value={add.opening_stock} onChange={(e) => setAdd((a) => ({ ...a, opening_stock: e.target.value }))} data-testid="add-ing-stock" className={inputCls} placeholder="0" /></Field>
            <div className="flex items-end"><button type="submit" data-testid="add-ing-submit" className="w-full rounded-xl bg-brand-terra py-2.5 text-sm font-semibold text-white">Save</button></div>
          </form>
        </Card>
      )}
      <DataTable testId="inventory-table" cols={["Ingredient", "Category", "Rate", "Book Stock", "At Departments", "Physical Count", "Variance", "Stock Value"]} rows={rows} />
    </div>
  );
}
