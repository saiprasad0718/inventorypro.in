import { useEffect, useState } from "react";
import { toast } from "sonner";
import api, { fmtErr } from "../api";
import { Card, Field, PageHead, inputCls } from "../components";

export default function Settings() {
  const [profile, setProfile] = useState({ restaurant_name: "", pos_system: "", currency: "INR", alert_enabled: true, alert_threshold: 3, recap_enabled: true, whatsapp_number: "919908659651" });
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ name: "", email: "", password: "", role: "chef" });
  const [confirmReset, setConfirmReset] = useState(false);
  const [outlets, setOutlets] = useState([]);
  const [outletName, setOutletName] = useState("");

  const load = () => {
    api.get("/settings").then((r) => setProfile(r.data)).catch((e) => toast.error(fmtErr(e)));
    api.get("/auth/users").then((r) => setUsers(r.data)).catch(() => {});
    api.get("/outlets").then((r) => setOutlets(r.data)).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const saveProfile = async (e) => {
    e.preventDefault();
    try {
      await api.put("/settings", profile);
      toast.success("Restaurant profile saved");
    } catch (e2) { toast.error(fmtErr(e2)); }
  };

  const addUser = async (e) => {
    e.preventDefault();
    try {
      await api.post("/auth/users", newUser);
      toast.success(`Account created for ${newUser.name}`);
      setNewUser({ name: "", email: "", password: "", role: "chef" });
      load();
    } catch (e2) { toast.error(fmtErr(e2)); }
  };

  const addOutlet = async (e) => {
    e.preventDefault();
    try {
      await api.post("/outlets", { name: outletName });
      toast.success(`Outlet "${outletName}" created with a copy of the current stock catalog`);
      setOutletName("");
      load();
    } catch (e2) { toast.error(fmtErr(e2)); }
  };

  const loadDemo = async (name) => {
    try {
      await api.post("/outlets/seed-demo", {}, { headers: { "X-Outlet": name } });
      toast.success(`Demo week loaded for ${name} — switch to it from the sidebar`);
    } catch (e2) { toast.error(fmtErr(e2)); }
  };

  const reset = async () => {
    if (!confirmReset) { setConfirmReset(true); return; }
    try {
      await api.post("/seed/reset");
      toast.success("Demo data reset to the original seeded state");
      setConfirmReset(false);
    } catch (e2) { toast.error(fmtErr(e2)); }
  };

  return (
    <div data-testid="settings-page">
      <PageHead title="Settings" sub="Restaurant profile, staff accounts and demo data" testId="settings-head" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card testId="settings-profile-card">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Restaurant Profile</p>
          <form onSubmit={saveProfile} className="space-y-4">
            <Field label="Restaurant Name"><input required value={profile.restaurant_name} onChange={(e) => setProfile((p) => ({ ...p, restaurant_name: e.target.value }))} data-testid="settings-name-input" className={inputCls} /></Field>
            <Field label="POS System"><input value={profile.pos_system} onChange={(e) => setProfile((p) => ({ ...p, pos_system: e.target.value }))} data-testid="settings-pos-input" className={inputCls} placeholder="Petpooja / Posist / manual entry" /></Field>
            <Field label="Currency"><input value={profile.currency} onChange={(e) => setProfile((p) => ({ ...p, currency: e.target.value }))} data-testid="settings-currency-input" className={inputCls} /></Field>
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <p className="mb-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Variance Alerts</p>
              <label className="flex items-start gap-3 text-sm">
                <input type="checkbox" checked={!!profile.alert_enabled} onChange={(e) => setProfile((p) => ({ ...p, alert_enabled: e.target.checked }))} data-testid="settings-alert-enabled" className="mt-0.5 size-4 accent-[#FF5722]" />
                Email me a morning summary (8:00 AM IST) when unexplained variance crosses the threshold
              </label>
              <div className="mt-3 flex items-center gap-3">
                <span className="text-sm text-muted-foreground">Threshold</span>
                <input type="number" min="1" max="200" value={profile.alert_threshold ?? 3} onChange={(e) => setProfile((p) => ({ ...p, alert_threshold: Number(e.target.value) }))} data-testid="settings-alert-threshold" className="w-24 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-brand-terra/60" />
                <span className="text-sm text-muted-foreground">portions</span>
              </div>
              <label className="mt-3 flex items-start gap-3 text-sm">
                <input type="checkbox" checked={!!profile.recap_enabled} onChange={(e) => setProfile((p) => ({ ...p, recap_enabled: e.target.checked }))} data-testid="settings-recap-enabled" className="mt-0.5 size-4 accent-[#FF5722]" />
                Also email me an evening recap (10:30 PM IST) with the full reconciliation status
              </label>
              <div className="mt-3 flex items-center gap-3">
                <span className="text-sm text-muted-foreground">WhatsApp summary to</span>
                <input value={profile.whatsapp_number ?? ""} onChange={(e) => setProfile((p) => ({ ...p, whatsapp_number: e.target.value }))} data-testid="settings-whatsapp-input" className="w-44 rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:border-brand-terra/60" placeholder="919908659651" />
              </div>
            </div>
            <button type="submit" data-testid="settings-save-button" className="w-full rounded-xl bg-brand-terra py-2.5 text-sm font-semibold text-white">Save Profile</button>
            <button
              type="button"
              data-testid="settings-send-alert-button"
              onClick={async () => {
                try {
                  const r = await api.post("/variance-alert/send");
                  toast.success(r.data.crossed
                    ? `Summary sent — variance is ABOVE threshold today (${r.data.total_unexplained} unexplained portions)`
                    : `Summary sent — variance is within threshold today (${r.data.total_unexplained} unexplained portions)`);
                } catch (e2) { toast.error(fmtErr(e2)); }
              }}
              className="w-full rounded-xl border border-brand-terra/50 py-2.5 text-sm font-semibold text-brand-terra transition-colors hover:bg-brand-terra hover:text-white"
            >
              Send Morning Summary Now
            </button>
            <div className="grid gap-2.5 sm:grid-cols-2">
              <button
                type="button"
                data-testid="settings-send-recap-button"
                onClick={async () => {
                  try {
                    await api.post("/evening-recap/send");
                    toast.success("Evening recap sent to your inbox");
                  } catch (e2) { toast.error(fmtErr(e2)); }
                }}
                className="rounded-xl border border-brand-gold/50 py-2.5 text-xs font-semibold text-brand-gold transition-colors hover:bg-brand-gold hover:text-black"
              >
                Send Evening Recap Now
              </button>
              <button
                type="button"
                data-testid="settings-whatsapp-alert-button"
                onClick={async () => {
                  try {
                    const r = await api.get("/variance-alert/whatsapp");
                    window.open(r.data.url, "_blank");
                  } catch (e2) { toast.error(fmtErr(e2)); }
                }}
                className="rounded-xl border border-brand-emerald/50 py-2.5 text-xs font-semibold text-brand-emerald transition-colors hover:bg-brand-emerald hover:text-white"
              >
                Get Summary on WhatsApp
              </button>
            </div>
          </form>
        </Card>

        <Card testId="settings-staff-card">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Staff Accounts</p>
          <ul className="mb-5 space-y-2">
            {users.map((u) => (
              <li key={u.id} className="flex items-center justify-between rounded-xl border border-white/8 bg-black/20 px-4 py-2.5 text-sm">
                <span>{u.name} <span className="text-muted-foreground">· {u.email}</span></span>
                <span className="rounded-full bg-brand-gold/15 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-widest text-brand-gold">{u.role}</span>
              </li>
            ))}
          </ul>
          <form onSubmit={addUser} className="grid gap-3 sm:grid-cols-2">
            <input required placeholder="Name" value={newUser.name} onChange={(e) => setNewUser((n) => ({ ...n, name: e.target.value }))} data-testid="staff-name-input" className={inputCls} />
            <input required type="email" placeholder="Email" value={newUser.email} onChange={(e) => setNewUser((n) => ({ ...n, email: e.target.value }))} data-testid="staff-email-input" className={inputCls} />
            <input required type="password" placeholder="Password (min 6 chars)" value={newUser.password} onChange={(e) => setNewUser((n) => ({ ...n, password: e.target.value }))} data-testid="staff-password-input" className={inputCls} />
            <select value={newUser.role} onChange={(e) => setNewUser((n) => ({ ...n, role: e.target.value }))} data-testid="staff-role-select" className={`${inputCls} appearance-none`}>
              <option value="chef" className="bg-brand-slate">Chef — production & wastage</option>
              <option value="manager" className="bg-brand-slate">Manager — everything except settings</option>
              <option value="owner" className="bg-brand-slate">Owner — full access</option>
            </select>
            <button type="submit" data-testid="staff-add-button" className="rounded-xl border border-brand-terra/50 py-2.5 text-sm font-semibold text-brand-terra transition-colors hover:bg-brand-terra hover:text-white sm:col-span-2">Create Account</button>
          </form>
        </Card>

        <Card testId="settings-outlets-card">
          <p className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Outlets / Branches</p>
          <ul className="mb-5 space-y-2">
            {outlets.map((o) => (
              <li key={o.id || o.name} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-black/20 px-4 py-2.5 text-sm">
                <span className="flex items-center gap-2"><span className="size-2 rounded-full bg-brand-gold" /> {o.name}</span>
                <button
                  type="button"
                  onClick={() => loadDemo(o.name)}
                  data-testid={`outlet-demo-${o.name.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                  className="shrink-0 rounded-full border border-brand-terra/50 px-3 py-1 text-[11px] font-semibold text-brand-terra transition-colors hover:bg-brand-terra hover:text-white"
                >
                  Load demo data
                </button>
              </li>
            ))}
          </ul>
          <form onSubmit={addOutlet} className="flex gap-3">
            <input required placeholder="New branch name, e.g. Jubilee Hills" value={outletName} onChange={(e) => setOutletName(e.target.value)} data-testid="outlet-name-input" className={inputCls} />
            <button type="submit" data-testid="outlet-add-button" className="shrink-0 rounded-xl bg-brand-terra px-5 py-2.5 text-sm font-semibold text-white">Add Outlet</button>
          </form>
          <p className="mt-3 text-xs text-muted-foreground">A new outlet starts with a copy of your current ingredient catalog and stock. Switch outlets from the sidebar.</p>
        </Card>

        <Card testId="settings-reset-card" className="lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Demo Data</p>
              <p className="mt-1 text-sm text-muted-foreground">Reset the app back to its original seeded demo day. All entries you made will be replaced.</p>
            </div>
            <button onClick={reset} data-testid="settings-reset-button"
              className={`rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${confirmReset ? "bg-brand-terra text-white" : "border border-brand-terra/50 text-brand-terra"}`}>
              {confirmReset ? "Click again to confirm reset" : "Reset Demo Data"}
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
