import { motion } from "framer-motion";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { TrendingDown, IndianRupee, Package, AlertTriangle } from "lucide-react";

const COLORS = ["#FF5722", "#E6A100", "#10B981", "#64748B", "#8B5CF6"];

const wastageData = [
  { name: "Prep trim", value: 38 },
  { name: "Spoilage", value: 27 },
  { name: "Kitchen errors", value: 21 },
  { name: "Customer returns", value: 14 },
];

const productionData = [
  { name: "Main Kitchen", value: 96 },
  { name: "Biryani Station", value: 68 },
  { name: "Tandoor", value: 44 },
  { name: "Curry Section", value: 38 },
];

const salesData = [
  { name: "Mains", value: 46 },
  { name: "Starters", value: 24 },
  { name: "Breads & Rice", value: 18 },
  { name: "Beverages", value: 8 },
  { name: "Desserts", value: 4 },
];

const varianceRows = [
  { item: "Chicken (kg)", expected: 12.0, actual: 12.6 },
  { item: "Onion (kg)", expected: 8.0, actual: 10.5 },
  { item: "Basmati Rice (kg)", expected: 15.0, actual: 15.2 },
  { item: "Yogurt (kg)", expected: 4.0, actual: 4.1 },
];

const kpis = [
  { icon: IndianRupee, label: "Today's Sales", value: "₹69,800", sub: "221 portions sold", tone: "text-foreground" },
  { icon: TrendingDown, label: "Food Cost", value: "31.3%", sub: "Within target ≤ 32%", tone: "text-brand-emerald" },
  { icon: Package, label: "Stock Value", value: "₹43,284", sub: "11 ingredients tracked", tone: "text-foreground" },
  { icon: AlertTriangle, label: "Wastage", value: "₹74", sub: "2 entries recorded", tone: "text-brand-gold" },
];

const Donut = ({ title, data, center, testId, unit }) => (
  <div className="glow-border rounded-2xl border border-white/10 bg-brand-slate p-6" data-testid={testId}>
    <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{title}</p>
    <div className="relative mt-2 h-52">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius="62%"
            outerRadius="88%"
            paddingAngle={3}
            stroke="none"
          >
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{ background: "#131620", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 12 }}
            itemStyle={{ color: "#F3F4F6" }}
            formatter={(v) => [`${v}${unit}`, ""]}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 grid place-items-center">
        <div className="text-center">
          <p className="font-display text-2xl font-bold">{center}</p>
          <p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">today</p>
        </div>
      </div>
    </div>
    <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1.5">
      {data.map((d, i) => (
        <span key={d.name} className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="size-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
          {d.name}
          <span className="ml-auto font-mono text-[11px] text-foreground">{d.value}{unit}</span>
        </span>
      ))}
    </div>
  </div>
);

export default function OwnerDashboard() {
  return (
    <section id="dashboard" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <motion.p
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="font-mono text-xs tracking-[0.3em] uppercase text-brand-gold"
        >
          The Owner's Command View
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-4 max-w-3xl font-display text-2xl font-bold tracking-tight sm:text-4xl"
        >
          Wastage, production and sales — compared side by side, in one glance.
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="mt-4 text-sm text-muted-foreground"
          data-testid="dashboard-demo-note"
        >
          Representative demo data for a single outlet day.
        </motion.p>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((k, i) => (
            <motion.div
              key={k.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.07 }}
              className="rounded-2xl border border-white/10 bg-brand-slate p-5"
              data-testid={`kpi-${k.label.toLowerCase().replace(/[^a-z]+/g, "-")}`}
            >
              <div className="flex items-center justify-between">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{k.label}</p>
                <k.icon className="size-4 text-brand-terra" />
              </div>
              <p className={`mt-3 font-display text-3xl font-extrabold tracking-tight ${k.tone}`}>{k.value}</p>
              <p className="mt-1 text-xs text-muted-foreground">{k.sub}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7 }}>
            <Donut title="Wastage Breakdown" data={wastageData} center="₹74" unit="%" testId="owner-wastage-pie-chart" />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7, delay: 0.1 }}>
            <Donut title="Production Volume by Station" data={productionData} center="246" unit="" testId="owner-production-pie-chart" />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7, delay: 0.2 }}>
            <Donut title="POS Sales by Category" data={salesData} center="₹69.8k" unit="%" testId="owner-sales-pie-chart" />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-6 rounded-2xl border border-white/10 bg-brand-slate p-6"
          data-testid="owner-variance-widget"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              Expected vs Actual Consumption
            </p>
            <div className="flex items-center gap-5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              <span className="flex items-center gap-2"><span className="h-2 w-4 rounded-sm bg-brand-emerald" /> Expected</span>
              <span className="flex items-center gap-2"><span className="h-2 w-4 rounded-sm bg-brand-terra" /> Actual</span>
            </div>
          </div>
          <div className="mt-6 space-y-5">
            {varianceRows.map((r) => {
              const max = Math.max(r.expected, r.actual);
              const over = r.actual > r.expected;
              return (
                <div key={r.item} className="grid items-center gap-2 sm:grid-cols-[160px_1fr_110px]">
                  <span className="text-sm text-foreground">{r.item}</span>
                  <div className="space-y-1.5">
                    <div className="h-2 rounded-full bg-white/5">
                      <div className="h-2 rounded-full bg-brand-emerald/70" style={{ width: `${(r.expected / max) * 100}%` }} />
                    </div>
                    <div className="h-2 rounded-full bg-white/5">
                      <div className="h-2 rounded-full bg-brand-terra" style={{ width: `${(r.actual / max) * 100}%` }} />
                    </div>
                  </div>
                  <span className={`font-mono text-xs ${over ? "text-brand-terra" : "text-brand-emerald"}`}>
                    {over ? "+" : ""}{(r.actual - r.expected).toFixed(1)} {over ? "over" : "on track"}
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
