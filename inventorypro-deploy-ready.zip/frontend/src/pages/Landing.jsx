import { useEffect } from "react";
import Lenis from "lenis";
import Seo from "@/components/Seo";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Manifesto from "@/components/Manifesto";
import OwnerDashboard from "@/components/OwnerDashboard";
import DemoSection from "@/components/DemoSection";
import TourTeaser from "@/components/TourTeaser";
import ContactForm from "@/components/ContactForm";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: "InventoryPro.in",
  applicationCategory: "BusinessApplication",
  operatingSystem: "Web",
  description:
    "Restaurant inventory, production and food-cost control for Indian restaurants. Track raw materials, production batches, wastage and reconcile every portion against POS sales.",
};

export default function Landing() {
  useEffect(() => {
    const lenis = new Lenis({ duration: 1.15, smoothWheel: true });
    let rafId;
    const raf = (time) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };
    rafId = requestAnimationFrame(raf);
    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);

  return (
    <div className="min-h-screen bg-brand-obsidian text-foreground overflow-x-clip">
      <Seo
        title="InventoryPro.in — Restaurant Inventory, Production & Food-Cost Control"
        siteName="InventoryPro.in"
        description="Track every gram, every batch, every portion. InventoryPro.in gives Indian restaurant owners one live view of inventory, production, wastage and POS reconciliation."
        jsonLd={jsonLd}
      />
      <div className="grain-overlay" aria-hidden="true" />
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <Manifesto />
        <OwnerDashboard />
        <DemoSection />
        <TourTeaser />
        <ContactForm />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
